#!/bin/bash
# test 4
test $(./check <<< "0 1 0 ; 0") = no 
