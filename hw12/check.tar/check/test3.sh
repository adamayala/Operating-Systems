#!/bin/bash
# test 3
test $(./check <<< "1 ;") = no 
