#!/bin/bash
# code compiles
rm -f merge
gcc -pthread -o merge merge.c
