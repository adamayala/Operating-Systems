#!/bin/bash
# test 4
test $(./blist <<< "a b") = no 
