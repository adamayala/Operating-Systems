#!/bin/bash
# test 3
test $(./blist <<< "") = no 
