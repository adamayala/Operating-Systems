#!/bin/bash
# test 1
test $(./blist <<< "a") = yes
