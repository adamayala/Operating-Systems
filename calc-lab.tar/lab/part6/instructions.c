
The expr.c file now contains an expr_eval() function that will evaluate
an expression and return its value.

Run 'make' and then 'make tests'.  You will see the printed output is incorrect.

Replace the two comments YOUR CODE HERE with your own code, and run
'make', and then 'make tests'.
