#!/bin/bash
./calc <<< "1 + 2"
./calc <<< "(1 * 2)"
./calc <<< "(3 - 1) * 5"
./calc <<< "3 - 1 * 5"
