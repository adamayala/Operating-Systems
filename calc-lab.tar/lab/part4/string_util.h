#ifndef STRING_UTIL_INC
#define STRING_UTIL_INC

char *str_dup(char *s);

#endif
