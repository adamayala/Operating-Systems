#ifndef PARSER_INC
#define PARSER_INC
#include "expr.h"

// parser methods
EXPR *parse();

#endif
